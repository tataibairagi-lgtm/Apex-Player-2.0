package com.apex.player

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/** Every user-facing setting lives here so the Settings screen and the player agree. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.applicationContext.getSharedPreferences("apex", Context.MODE_PRIVATE)
    }

    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    val DEFAULT_ACCENT: Int = Color.parseColor("#F2C14E")

    /* appearance */
    var accent: Int
        get() = int("accent", DEFAULT_ACCENT)
        set(v) = putInt("accent", v)
    var amoled: Boolean
        get() = bool("amoled", false)
        set(v) = putBool("amoled", v)
    var hideSec: Int
        get() = int("hideSec", 4)
        set(v) = putInt("hideSec", v)
    var resizeIdx: Int
        get() = int("resizeIdx", 0)
        set(v) = putInt("resizeIdx", v)
    var subSize: Int
        get() = int("subSize", 100)
        set(v) = putInt("subSize", v)
    var subColor: Int
        get() = int("subColor", Color.WHITE)
        set(v) = putInt("subColor", v)

    /* playback */
    var seekStep: Int
        get() = int("seekStep", 10)
        set(v) = putInt("seekStep", v)
    var resume: Boolean
        get() = bool("resume", true)
        set(v) = putBool("resume", v)
    var pauseBg: Boolean
        get() = bool("pauseBg", true)
        set(v) = putBool("pauseBg", v)
    var autoPip: Boolean
        get() = bool("autoPip", true)
        set(v) = putBool("autoPip", v)

    /* gestures */
    var gSeek: Boolean
        get() = bool("gSeek", true)
        set(v) = putBool("gSeek", v)
    var gBright: Boolean
        get() = bool("gBright", true)
        set(v) = putBool("gBright", v)
    var gVol: Boolean
        get() = bool("gVol", true)
        set(v) = putBool("gVol", v)
    var gTap: Boolean
        get() = bool("gTap", true)
        set(v) = putBool("gTap", v)
    var gHold: Boolean
        get() = bool("gHold", true)
        set(v) = putBool("gHold", v)
    var gPinch: Boolean
        get() = bool("gPinch", true)
        set(v) = putBool("gPinch", v)

    /* audio effects */
    var eqOn: Boolean
        get() = bool("eqOn", false)
        set(v) = putBool("eqOn", v)
    var eqBands: String
        get() = sp.getString("eqBands", "") ?: ""
        set(v) = sp.edit().putString("eqBands", v).apply()
    var boost: Int
        get() = int("boost", 0)
        set(v) = putInt("boost", v)

    fun resetAppearanceAndBehaviour() {
        sp.edit().clear().apply()
    }

    /* resume positions */
    fun getPos(id: String): Long = sp.getLong("p:$id", 0L)
    fun setPos(id: String, ms: Long) = sp.edit().putLong("p:$id", ms).apply()
    fun clearPos(id: String) = sp.edit().remove("p:$id").apply()

    /* recently played */
    data class Recent(val uri: String, val title: String)

    fun recents(): List<Recent> {
        val out = ArrayList<Recent>()
        try {
            val arr = JSONArray(sp.getString("recent", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Recent(o.getString("u"), o.getString("t")))
            }
        } catch (e: Exception) {
            // corrupt data: start over
        }
        return out
    }

    fun addRecent(uri: String, title: String) {
        val list = recents().filter { it.uri != uri }.toMutableList()
        list.add(0, Recent(uri, title))
        val arr = JSONArray()
        list.take(12).forEach { arr.put(JSONObject().put("u", it.uri).put("t", it.title)) }
        sp.edit().putString("recent", arr.toString()).apply()
    }

    fun clearRecents() = sp.edit().remove("recent").apply()
}
