package com.apex.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile

class MainActivity : AppCompatActivity() {

    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) openUris(uris)
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) openFolder(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        super.onCreate(savedInstanceState)
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.background = appBackground()
        scroll.isFillViewport = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(28))
        scroll.addView(col, LinearLayout.LayoutParams(MATCH, WRAP))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.apex_logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.setPadding(dp(12), 0, 0, 0)
        val word = label("APEX", 20f, TEXT, true)
        word.letterSpacing = 0.12f
        val sub = label("PLAYER", 10f, Prefs.accent, true)
        sub.letterSpacing = 0.5f
        names.addView(word)
        names.addView(sub)
        head.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(pill("Settings", false) { startActivity(Intent(this, SettingsActivity::class.java)) })
        col.addView(head)

        // hero
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(20), dp(22), dp(20), dp(22))
        hero.background = rounded(SURFACE, 24, LINE, 1)
        hero.addView(label("Play anything your phone can decode", 22f, TEXT, true))
        val blurb = label("Videos, music, whole folders and network streams. Subtitles are picked up automatically when they share a name with the video.", 13f, MUTED)
        blurb.setPadding(0, dp(8), 0, dp(16))
        hero.addView(blurb)
        val open = pill("Open files", true) { pickFiles.launch(arrayOf("*/*")) }
        hero.addView(open, LinearLayout.LayoutParams(MATCH, WRAP))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(10), 0, 0)
        val folder = pill("Open folder", false) { pickFolder.launch(null) }
        val stream = pill("Network stream", false) { streamDialog() }
        val lpA = LinearLayout.LayoutParams(0, WRAP, 1f)
        lpA.rightMargin = dp(5)
        val lpB = LinearLayout.LayoutParams(0, WRAP, 1f)
        lpB.leftMargin = dp(5)
        row.addView(folder, lpA)
        row.addView(stream, lpB)
        hero.addView(row)
        val lpHero = LinearLayout.LayoutParams(MATCH, WRAP)
        lpHero.topMargin = dp(26)
        col.addView(hero, lpHero)

        // recents
        col.addView(sectionTitle("Continue watching"))
        val recents = Prefs.recents()
        if (recents.isEmpty()) {
            col.addView(label("Nothing yet. Files you play show up here.", 13f, MUTED))
        } else {
            recents.forEach { r ->
                val item = LinearLayout(this)
                item.orientation = LinearLayout.VERTICAL
                item.setPadding(dp(14), dp(12), dp(14), dp(12))
                item.background = rounded(SURFACE, 14, LINE, 1)
                val t = label(r.title, 15f, TEXT, true)
                t.maxLines = 1
                t.ellipsize = android.text.TextUtils.TruncateAt.END
                item.addView(t)
                val pos = Prefs.getPos(r.uri)
                item.addView(label(if (pos > 5000) "Resume from ${fmtTime(pos)}" else "Play from the start", 12f, MUTED))
                item.setOnClickListener { play(listOf(Entry(Uri.parse(r.uri), r.title)), 0) }
                val lp = LinearLayout.LayoutParams(MATCH, WRAP)
                lp.bottomMargin = dp(8)
                col.addView(item, lp)
            }
            val clear = label("Clear history", 12f, MUTED)
            clear.setPadding(0, dp(10), 0, 0)
            clear.setOnClickListener { Prefs.clearRecents(); build() }
            col.addView(clear)
        }
        setContentView(scroll)
    }

    private fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun play(entries: List<Entry>, start: Int) {
        Queue.items = entries
        Queue.start = start
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra("queue", true)
        startActivity(i)
    }

    private fun keepAccess(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // not every provider offers persistable access; playing still works this session
        }
    }

    private fun openUris(uris: List<Uri>) {
        val files = uris.map { u ->
            keepAccess(u)
            Pair(u, displayName(this, u) ?: "file")
        }
        val entries = buildEntries(files, false)
        if (entries.isEmpty()) {
            Toast.makeText(this, "Pick a video or audio file.", Toast.LENGTH_LONG).show()
            return
        }
        play(entries, 0)
    }

    private fun openFolder(tree: Uri) {
        keepAccess(tree)
        Toast.makeText(this, "Scanning folder…", Toast.LENGTH_SHORT).show()
        val ctx: Context = this
        Thread {
            val found = ArrayList<Pair<Uri, String>>()
            fun walk(dir: DocumentFile, depth: Int) {
                for (f in dir.listFiles()) {
                    val name = f.name ?: continue
                    if (f.isDirectory) {
                        if (depth < 3) walk(f, depth + 1)
                    } else if (isMediaName(name) || isSubName(name)) {
                        found.add(Pair(f.uri, name))
                    }
                }
            }
            try {
                val root = DocumentFile.fromTreeUri(ctx, tree)
                if (root != null) walk(root, 0)
            } catch (e: Exception) {
                // report below as an empty folder
            }
            val entries = buildEntries(found, true)
            runOnUiThread {
                if (entries.isEmpty()) Toast.makeText(ctx, "No videos or music found in that folder.", Toast.LENGTH_LONG).show()
                else play(entries, 0)
            }
        }.start()
    }

    private fun streamDialog() {
        val input = EditText(this)
        input.hint = "https://example.com/video.mp4"
        input.setTextColor(TEXT)
        input.setHintTextColor(MUTED)
        input.setSingleLine(true)
        val pad = dp(20)
        val box = LinearLayout(this)
        box.setPadding(pad, dp(8), pad, 0)
        box.addView(input, LinearLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setMessage("Paste a link to a video, music file, HLS (.m3u8) or DASH (.mpd) stream.")
            .setView(box)
            .setPositiveButton("Play") { _, _ ->
                val url = input.text.toString().trim()
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    val name = Uri.parse(url).lastPathSegment ?: url
                    play(listOf(Entry(Uri.parse(url), stripExt(name))), 0)
                } else {
                    Toast.makeText(this, "Enter a link that starts with http:// or https://", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
