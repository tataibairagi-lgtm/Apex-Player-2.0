package com.apex.player

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        super.onCreate(savedInstanceState)
        build()
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.background = appBackground()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), dp(40))
        scroll.addView(col, LinearLayout.LayoutParams(MATCH, WRAP))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label("Settings", 22f, TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(pill("Done", true) { finish() })
        col.addView(head)

        // ----- appearance -----
        col.addView(sectionTitle("Appearance"))
        val accents = listOf("#F2C14E", "#B69CFF", "#4FD6C8", "#FF7AA8", "#9BE564", "#FF8A4C", "#5AA9FF").map { Color.parseColor(it) }
        col.addView(swatchRow("Accent colour", accents, Prefs.accent) { Prefs.accent = it; build() })
        col.addView(segRow("Surface", listOf("Violet", "AMOLED black"), if (Prefs.amoled) 1 else 0) { Prefs.amoled = it == 1; build() })
        col.addView(seekRow("Hide controls after", 2, 10, Prefs.hideSec, " s") { Prefs.hideSec = it })
        col.addView(segRow("Default picture size", listOf("Fit", "Stretch", "Crop"), Prefs.resizeIdx.coerceIn(0, 2)) { Prefs.resizeIdx = it })

        // ----- subtitles -----
        col.addView(sectionTitle("Subtitles"))
        col.addView(seekRow("Text size", 50, 250, Prefs.subSize, "%") { Prefs.subSize = it })
        val subColors = listOf("#FFFFFF", "#FFE066", "#7EF0FF", "#B6FF8A").map { Color.parseColor(it) }
        col.addView(swatchRow("Text colour", subColors, Prefs.subColor) { Prefs.subColor = it })

        // ----- playback -----
        col.addView(sectionTitle("Playback"))
        col.addView(switchRow("Resume where you left off", "Remembers the position of each file.", Prefs.resume) { Prefs.resume = it })
        col.addView(divider())
        col.addView(segRow("Skip step", listOf("5 s", "10 s", "15 s", "30 s"), listOf(5, 10, 15, 30).indexOf(Prefs.seekStep).coerceAtLeast(0)) {
            Prefs.seekStep = listOf(5, 10, 15, 30)[it]
        })
        col.addView(switchRow("Pause when you leave the app", "Turn off to keep audio playing in the background.", Prefs.pauseBg) { Prefs.pauseBg = it })
        col.addView(divider())
        col.addView(switchRow("Picture-in-picture on exit", "Shrinks video to a floating window when you press Home.", Prefs.autoPip) { Prefs.autoPip = it })

        // ----- gestures -----
        col.addView(sectionTitle("Gestures"))
        col.addView(switchRow("Swipe sideways to seek", null, Prefs.gSeek) { Prefs.gSeek = it })
        col.addView(divider())
        col.addView(switchRow("Swipe left edge for brightness", null, Prefs.gBright) { Prefs.gBright = it })
        col.addView(divider())
        col.addView(switchRow("Swipe right edge for volume", null, Prefs.gVol) { Prefs.gVol = it })
        col.addView(divider())
        col.addView(switchRow("Double-tap to skip or pause", "Left and right thirds skip, the middle pauses.", Prefs.gTap) { Prefs.gTap = it })
        col.addView(divider())
        col.addView(switchRow("Touch and hold for 2× speed", null, Prefs.gHold) { Prefs.gHold = it })
        col.addView(divider())
        col.addView(switchRow("Pinch to zoom, drag to pan", null, Prefs.gPinch) { Prefs.gPinch = it })

        // ----- reset / about -----
        col.addView(sectionTitle("About"))
        val about = label(
            "Apex Player 1.0. Plays what your device can decode: H.264, HEVC, VP9, AV1, AAC, MP3, FLAC, Opus and more, in MP4, MKV, WebM, TS and other containers. Which codecs work depends on your phone's hardware.",
            12f, MUTED
        )
        col.addView(about)
        val reset = pill("Reset all settings", false) { Prefs.resetAppearanceAndBehaviour(); build() }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = dp(16)
        col.addView(reset, lp)

        setContentView(scroll)
    }
}
