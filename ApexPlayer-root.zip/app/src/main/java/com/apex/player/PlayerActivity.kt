package com.apex.player

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import java.util.Locale
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null

    private lateinit var root: FrameLayout
    private lateinit var pv: PlayerView
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var hudView: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var abBtn: TextView
    private lateinit var aspectBtn: TextView
    private lateinit var audioMgr: AudioManager

    private var locked = false
    private var inPip = false
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop", "Fit width", "Fit height")
    private var resizeIdx = 0

    private var abA = -1L
    private var abB = -1L

    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null

    private var userRotated = false
    private var orientIdx = 0

    private var sleepEnd = false
    private var sleepRun: Runnable? = null
    private val resumed = HashSet<String>()

    // gesture state
    private var gMode = 0 // 0 undecided, 1 seek, 2 brightness, 3 volume, -1 ignored
    private var gStartPos = 0L
    private var gTarget = -1L
    private var volF = 0f
    private var briF = 0.5f
    private var holding = false
    private var holdPrev = 1f
    private var lastSave = 0L

    private val subPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }

    /* ------------------------------------------------------------------ lifecycle */

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        super.onCreate(savedInstanceState)
        audioMgr = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        resizeIdx = Prefs.resizeIdx.coerceIn(0, resizeModes.size - 1)
        buildUi()
        initPlayer()
        loadFromIntent(intent)
        hideSystemBars()
        handler.post(ticker)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadFromIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val p = player
        if (Build.VERSION.SDK_INT >= 26 && Prefs.autoPip && p != null && p.isPlaying && !locked) enterPip(false)
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        pv.useController = !isInPictureInPictureMode
        topBar.visibility = if (isInPictureInPictureMode) View.GONE else topBar.visibility
        if (isInPictureInPictureMode) hudView.visibility = View.GONE
    }

    override fun onStop() {
        super.onStop()
        savePos()
        val p = player
        if (p != null && Prefs.pauseBg && !inPip) p.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        savePos()
        pv.player = null
        releaseEffects()
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    /* ------------------------------------------------------------------ UI */

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun overlayPill(text: String, onClick: () -> Unit): TextView {
        val t = label(text, 13f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.background = rounded(Color.parseColor("#59000000"), 18, Color.parseColor("#33FFFFFF"), 1)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        pv = PlayerView(this)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        pv.setControllerShowTimeoutMs(Prefs.hideSec * 1000)
        pv.setControllerHideOnTouch(false)
        pv.setShowSubtitleButton(true)
        pv.setShowShuffleButton(true)
        pv.setShowNextButton(true)
        pv.setShowPreviousButton(true)
        pv.setKeepContentOnPlayerReset(true)
        pv.resizeMode = resizeModes[resizeIdx]
        pv.defaultArtwork = resources.getDrawable(R.drawable.apex_logo, theme)
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            if (!inPip && !locked) topBar.visibility = vis else topBar.visibility = View.GONE
        })
        styleControls()
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar: back + title, then a scrolling row of tools
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT)
        )
        topBar.setPadding(dp(8), dp(8), dp(8), dp(22))

        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val back = label("‹", 30f, Color.WHITE, true)
        back.setPadding(dp(12), 0, dp(14), dp(4))
        back.setOnClickListener { finish() }
        titleRow.addView(back)
        titleView = label("", 15f, Color.WHITE, true)
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        titleRow.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        topBar.addView(titleRow)

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.setPadding(dp(6), dp(8), dp(6), 0)
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.rightMargin = dp(8)
            tools.addView(v, lp)
        }
        abBtn = overlayPill("A–B") { cycleAb() }
        aspectBtn = overlayPill(resizeNames[resizeIdx]) { cycleAspect() }
        add(abBtn)
        add(aspectBtn)
        add(overlayPill("Rotate") { rotateScreen() })
        add(overlayPill("Audio") { showTracks(C.TRACK_TYPE_AUDIO) })
        add(overlayPill("Subtitles") { showTracks(C.TRACK_TYPE_TEXT) })
        add(overlayPill("Equalizer") { showEffects() })
        add(overlayPill("Sleep") { showSleep() })
        add(overlayPill("PiP") { enterPip(true) })
        add(overlayPill("Lock") { setLocked(true) })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tools)
        topBar.addView(hs)
        root.addView(topBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topBar.setPadding(dp(8) + bars.left, dp(8) + bars.top, dp(8) + bars.right, dp(22))
            insets
        }

        hudView = label("", 20f, Color.WHITE, true)
        hudView.gravity = Gravity.CENTER
        hudView.setPadding(dp(22), dp(12), dp(22), dp(12))
        hudView.background = rounded(Color.parseColor("#B3000000"), 16)
        hudView.visibility = View.GONE
        root.addView(hudView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        unlockBtn = label("Tap to unlock", 14f, Color.WHITE, true)
        unlockBtn.gravity = Gravity.CENTER
        unlockBtn.setPadding(dp(22), dp(12), dp(22), dp(12))
        unlockBtn.background = rounded(Prefs.accent, 24)
        unlockBtn.setTextColor(inkOn(Prefs.accent))
        unlockBtn.visibility = View.GONE
        unlockBtn.setOnClickListener { setLocked(false) }
        val ulp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        ulp.bottomMargin = dp(48)
        root.addView(unlockBtn, ulp)

        setContentView(root)
        setupGestures()
    }

    /** Applies the user's accent colour and subtitle style. */
    private fun styleControls() {
        try {
            val bar = pv.findViewById<DefaultTimeBar>(androidx.media3.ui.R.id.exo_progress)
            bar?.setPlayedColor(Prefs.accent)
            bar?.setScrubberColor(Prefs.accent)
        } catch (e: Exception) {
            // the stock controller layout changed; the default colours still work
        }
        val sv = pv.subtitleView
        if (sv != null) {
            sv.setStyle(
                CaptionStyleCompat(
                    Prefs.subColor, Color.parseColor("#66000000"), Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null
                )
            )
            sv.setFractionalTextSize(0.0533f * Prefs.subSize / 100f)
        }
    }

    private var hudHide = Runnable { hudView.visibility = View.GONE }
    private fun hud(text: String, ms: Long = 900) {
        if (inPip) return
        hudView.text = text
        hudView.visibility = View.VISIBLE
        handler.removeCallbacks(hudHide)
        handler.postDelayed(hudHide, ms)
    }

    private fun fmt(ms: Long): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    /* ------------------------------------------------------------------ player */

    private fun initPlayer() {
        val factory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, factory)
            .setSeekBackIncrementMs(Prefs.seekStep * 1000L)
            .setSeekForwardIncrementMs(Prefs.seekStep * 1000L)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .build()
        p.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                onItemChanged(mediaItem, reason)
            }

            override fun onPlayerError(error: PlaybackException) {
                toast("Can't play this one (" + error.errorCodeName + "). Your device may not support its video or audio format.")
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (!userRotated && videoSize.width > 0 && videoSize.height > 0) {
                    requestedOrientation = if (videoSize.width >= videoSize.height)
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                setupEffects(audioSessionId)
            }
        })
        pv.player = p
        player = p
        setupEffects(p.audioSessionId)
    }

    private fun subConfig(s: Sub): MediaItem.SubtitleConfiguration? {
        val n = s.name.lowercase()
        val mime = when {
            n.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
            n.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            n.endsWith(".ass") || n.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> return null
        }
        return MediaItem.SubtitleConfiguration.Builder(s.uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setLabel(stripExt(s.name))
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
    }

    private fun loadFromIntent(i: Intent) {
        val entries: List<Entry>
        var start = 0
        if (i.getBooleanExtra("queue", false) && Queue.items.isNotEmpty()) {
            entries = Queue.items
            start = Queue.start.coerceIn(0, Queue.items.size - 1)
        } else {
            val uri: Uri = i.data ?: run { finish(); return }
            val name = displayName(this, uri) ?: "Video"
            entries = listOf(Entry(uri, stripExt(name)))
        }
        val p = player ?: return
        val items = entries.map { e ->
            val b = MediaItem.Builder()
                .setUri(e.uri)
                .setMediaId(e.uri.toString())
                .setMediaMetadata(MediaMetadata.Builder().setTitle(e.title).build())
            val subs = e.subs.mapNotNull { subConfig(it) }
            if (subs.isNotEmpty()) b.setSubtitleConfigurations(subs)
            b.build()
        }
        resumed.clear()
        val first = entries[start]
        Prefs.addRecent(first.uri.toString(), first.title)
        p.setMediaItems(items, start, C.TIME_UNSET)
        p.prepare()
        p.playWhenReady = true
    }

    private fun onItemChanged(item: MediaItem?, reason: Int) {
        val p = player ?: return
        if (item == null) return
        titleView.text = item.mediaMetadata.title ?: ""
        abA = -1L
        abB = -1L
        updateAbLabel()
        resetZoom()
        if (Prefs.resume && resumed.add(item.mediaId)) {
            val pos = Prefs.getPos(item.mediaId)
            if (pos > 5000L) {
                p.seekTo(pos)
                hud("Resumed at " + fmt(pos), 1600)
            }
        }
        if (sleepEnd && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
            p.pause()
            sleepEnd = false
            hud("Sleep timer: paused", 2000)
        }
    }

    private fun savePos() {
        val p = player ?: return
        val item = p.currentMediaItem ?: return
        val d = p.duration
        val pos = p.currentPosition
        if (d != C.TIME_UNSET && pos > 5000L && pos < d - 10000L) Prefs.setPos(item.mediaId, pos) else Prefs.clearPos(item.mediaId)
    }

    /** Runs a few times a second: A–B looping and periodic position saving. */
    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null) {
                if (abA >= 0 && abB > abA && p.currentPosition >= abB) p.seekTo(abA)
                val now = System.currentTimeMillis()
                if (p.isPlaying && now - lastSave > 5000) {
                    lastSave = now
                    savePos()
                }
            }
            handler.postDelayed(this, 150)
        }
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) {
            p.seekTo(0)
            p.play()
        } else if (p.isPlaying) p.pause() else p.play()
    }

    private fun skip(ms: Long) {
        val p = player ?: return
        val d = p.duration
        val max = if (d == C.TIME_UNSET) Long.MAX_VALUE else d
        p.seekTo((p.currentPosition + ms).coerceIn(0L, max))
        hud((if (ms > 0) "+" else "−") + abs(ms / 1000) + " s")
    }

    /* ------------------------------------------------------------------ gestures */

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!Prefs.gTap) return false
                val w = pv.width.toFloat()
                when {
                    e.x < w / 3f -> skip(-Prefs.seekStep * 1000L)
                    e.x > w * 2f / 3f -> skip(Prefs.seekStep * 1000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val p = player ?: return
                if (!Prefs.gHold || gMode != 0) return
                holding = true
                holdPrev = p.playbackParameters.speed
                p.setPlaybackSpeed(2f)
                hud("2× speed", 60000)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                val p = player ?: return false
                if (e1 == null || holding) return false
                if (zoom > 1.01f) {
                    panX -= distanceX
                    panY -= distanceY
                    applyZoom()
                    return true
                }
                if (gMode == 0) {
                    val horizontal = abs(distanceX) > abs(distanceY)
                    gMode = if (horizontal) {
                        if (Prefs.gSeek && p.duration != C.TIME_UNSET) 1 else -1
                    } else if (e1.x < pv.width / 2f) {
                        if (Prefs.gBright) 2 else -1
                    } else {
                        if (Prefs.gVol) 3 else -1
                    }
                    gStartPos = p.currentPosition
                    briF = currentBrightness()
                    val max = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    volF = audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    if (gMode == 1) pv.hideController()
                }
                when (gMode) {
                    1 -> {
                        val d = p.duration
                        val delta = ((e2.x - e1.x) / pv.width * 90000f).toLong()
                        gTarget = (gStartPos + delta).coerceIn(0L, d)
                        val diff = (gTarget - gStartPos) / 1000
                        hud((if (diff >= 0) "+" else "−") + abs(diff) + " s   " + fmt(gTarget), 1200)
                    }
                    2 -> {
                        briF = (briF + distanceY / pv.height * 1.3f).coerceIn(0.02f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = briF
                        window.attributes = lp
                        hud("Brightness " + (briF * 100).roundToInt() + "%")
                    }
                    3 -> {
                        val max = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        volF = (volF + distanceY / pv.height * 1.3f).coerceIn(0f, 1f)
                        audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
                        hud("Volume " + (volF * 100).roundToInt() + "%")
                    }
                }
                return true
            }
        })

        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (!Prefs.gPinch) return false
                zoom = (zoom * d.scaleFactor).coerceIn(1f, 5f)
                applyZoom()
                hud("Zoom " + (zoom * 100).roundToInt() + "%", 700)
                return true
            }
        })

        pv.setOnTouchListener { _, ev ->
            if (locked) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) showUnlockHint()
                return@setOnTouchListener true
            }
            scaler.onTouchEvent(ev)
            if (!scaler.isInProgress && ev.pointerCount == 1) detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                finishGesture()
            }
            true
        }
    }

    private fun finishGesture() {
        val p = player
        if (gMode == 1 && gTarget >= 0 && p != null) p.seekTo(gTarget)
        if (holding && p != null) {
            p.setPlaybackSpeed(holdPrev)
            holding = false
        }
        gMode = 0
        gTarget = -1L
        handler.removeCallbacks(hudHide)
        handler.postDelayed(hudHide, 500)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun applyZoom() {
        val v = pv.videoSurfaceView ?: return
        if (zoom <= 1.01f) {
            panX = 0f
            panY = 0f
        }
        v.scaleX = zoom
        v.scaleY = zoom
        v.translationX = panX
        v.translationY = panY
    }

    private fun resetZoom() {
        zoom = 1f
        applyZoom()
    }

    /* ------------------------------------------------------------------ toolbar actions */

    private fun cycleAspect() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        pv.resizeMode = resizeModes[resizeIdx]
        aspectBtn.text = resizeNames[resizeIdx]
        resetZoom()
        hud(resizeNames[resizeIdx])
    }

    private fun cycleAb() {
        val p = player ?: return
        val pos = p.currentPosition
        if (abA < 0) {
            abA = pos
            hud("Loop start " + fmt(pos))
        } else if (abB < 0) {
            if (pos <= abA + 300) {
                hud("Set B after A")
                return
            }
            abB = pos
            hud("Looping " + fmt(abA) + " → " + fmt(abB), 1600)
        } else {
            abA = -1L
            abB = -1L
            hud("Loop cleared")
        }
        updateAbLabel()
    }

    private fun updateAbLabel() {
        abBtn.text = when {
            abA < 0 -> "A–B"
            abB < 0 -> "A set"
            else -> "A↔B on"
        }
    }

    private fun rotateScreen() {
        userRotated = true
        orientIdx = (orientIdx + 1) % 3
        requestedOrientation = when (orientIdx) {
            0 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        hud(arrayOf("Landscape", "Portrait", "Auto rotate")[orientIdx])
    }

    private fun setLocked(on: Boolean) {
        locked = on
        if (on) {
            pv.hideController()
            topBar.visibility = View.GONE
            hud("Controls locked")
            showUnlockHint()
        } else {
            unlockBtn.visibility = View.GONE
            pv.showController()
            hud("Unlocked")
        }
    }

    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private fun showUnlockHint() {
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
    }

    private fun enterPip(userTapped: Boolean) {
        if (Build.VERSION.SDK_INT < 26) {
            if (userTapped) toast("Picture-in-picture needs Android 8 or newer.")
            return
        }
        try {
            val vs = player?.videoSize
            var w = 16
            var h = 9
            if (vs != null && vs.width > 0 && vs.height > 0) {
                w = vs.width
                h = vs.height
            }
            val ratio = w.toDouble() / h
            val r = when {
                ratio > 2.39 -> Rational(239, 100)
                ratio < 0.42 -> Rational(100, 239)
                else -> Rational(w, h)
            }
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(r).build())
        } catch (e: Exception) {
            if (userTapped) toast("Picture-in-picture isn't available on this device.")
        }
    }

    private fun showSleep() {
        val names = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "End of this video")
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(names) { _, which ->
                sleepRun?.let { handler.removeCallbacks(it) }
                sleepRun = null
                sleepEnd = false
                when (which) {
                    0 -> hud("Sleep timer off")
                    5 -> {
                        sleepEnd = true
                        hud("Will pause after this video", 1600)
                    }
                    else -> {
                        val mins = intArrayOf(0, 15, 30, 45, 60)[which]
                        val r = Runnable {
                            player?.pause()
                            hud("Sleep timer: paused", 2000)
                        }
                        sleepRun = r
                        handler.postDelayed(r, mins * 60_000L)
                        hud("Sleeping in $mins min", 1600)
                    }
                }
            }
            .show()
    }

    private fun addSubtitle(uri: Uri) {
        val p = player ?: return
        val cur = p.currentMediaItem ?: return
        val name = displayName(this, uri) ?: "subtitle.srt"
        val conf = subConfig(Sub(uri, name))
        if (conf == null) {
            toast("Use an SRT, VTT or ASS subtitle file.")
            return
        }
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // fine, access lasts for this session
        }
        val idx = p.currentMediaItemIndex
        val pos = p.currentPosition
        val existing = cur.localConfiguration?.subtitleConfigurations ?: emptyList()
        val item = cur.buildUpon().setSubtitleConfigurations(existing + conf).build()
        p.replaceMediaItem(idx, item)
        p.seekTo(idx, pos)
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        hud("Subtitles added: " + stripExt(name), 1600)
    }

    /* ------------------------------------------------------------------ audio & subtitle tracks */

    private fun codecName(mime: String?): String = when (mime) {
        MimeTypes.AUDIO_AC3 -> "AC3"
        MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "E-AC3"
        MimeTypes.AUDIO_DTS -> "DTS"
        MimeTypes.AUDIO_DTS_HD -> "DTS-HD"
        MimeTypes.AUDIO_DTS_EXPRESS -> "DTS Express"
        MimeTypes.AUDIO_TRUEHD -> "TrueHD"
        MimeTypes.AUDIO_AAC -> "AAC"
        MimeTypes.AUDIO_MPEG -> "MP3"
        MimeTypes.AUDIO_OPUS -> "Opus"
        MimeTypes.AUDIO_VORBIS -> "Vorbis"
        MimeTypes.AUDIO_FLAC -> "FLAC"
        MimeTypes.AUDIO_ALAC -> "ALAC"
        else -> ""
    }

    private fun channelName(n: Int): String = when (n) {
        1 -> "mono"
        2 -> "stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> if (n > 0) "$n ch" else ""
    }

    private fun trackLabel(g: Tracks.Group, index: Int, audio: Boolean): String {
        val f = g.getTrackFormat(0)
        val lang = f.language
        var name = f.label
        if (name.isNullOrBlank()) {
            name = if (lang != null && lang != "und") Locale(lang).displayLanguage else ""
        }
        if (name.isNullOrBlank()) name = (if (audio) "Audio " else "Subtitle ") + (index + 1)
        val extra = ArrayList<String>()
        if (audio) {
            val c = codecName(f.sampleMimeType)
            if (c.isNotEmpty()) extra.add(c)
            val ch = channelName(f.channelCount)
            if (ch.isNotEmpty()) extra.add(ch)
        }
        if (!g.isSupported) extra.add("unsupported")
        return if (extra.isEmpty()) name else name + "  ·  " + extra.joinToString(" ")
    }

    private fun showTracks(type: Int) {
        val p = player ?: return
        val audio = type == C.TRACK_TYPE_AUDIO
        val groups = p.currentTracks.groups.filter { it.type == type }
        val labels = ArrayList<String>()
        var checked = -1
        if (!audio) {
            labels.add("Off")
            if (p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || groups.none { it.isSelected }) checked = 0
        }
        val offset = labels.size
        groups.forEachIndexed { i, g ->
            labels.add(trackLabel(g, i, audio))
            if (g.isSelected && !(!audio && p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))) checked = i + offset
        }
        if (!audio) labels.add("Add subtitle file…")
        if (audio && groups.isEmpty()) {
            toast("No audio tracks yet. Wait for the video to start, then try again.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle(if (audio) "Audio track (" + groups.size + ")" else "Subtitles (" + groups.size + ")")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { dialog, which ->
                dialog.dismiss()
                val b = p.trackSelectionParameters.buildUpon()
                if (!audio && which == 0) {
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    p.trackSelectionParameters = b.build()
                    hud("Subtitles off")
                } else if (!audio && which == labels.size - 1) {
                    subPicker.launch(arrayOf("*/*"))
                } else {
                    val g = groups[which - offset]
                    b.setTrackTypeDisabled(type, false)
                    b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
                    p.trackSelectionParameters = b.build()
                    hud(trackLabel(g, which - offset, audio), 1600)
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /* ------------------------------------------------------------------ audio effects */

    private fun releaseEffects() {
        try { eq?.release() } catch (e: Exception) { /* already gone */ }
        try { loud?.release() } catch (e: Exception) { /* already gone */ }
        eq = null
        loud = null
    }

    private fun setupEffects(sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        releaseEffects()
        try {
            val e = Equalizer(0, sessionId)
            val saved = Prefs.eqBands.split(",").mapNotNull { it.toIntOrNull() }
            if (saved.size == e.numberOfBands.toInt()) {
                for (b in saved.indices) e.setBandLevel(b.toShort(), saved[b].toShort())
            }
            e.setEnabled(Prefs.eqOn)
            eq = e
        } catch (e: Exception) {
            eq = null
        }
        try {
            val l = LoudnessEnhancer(sessionId)
            l.setTargetGain(Prefs.boost)
            l.setEnabled(Prefs.boost > 0)
            loud = l
        } catch (e: Exception) {
            loud = null
        }
    }

    private fun saveBands(e: Equalizer) {
        val parts = ArrayList<String>()
        for (b in 0 until e.numberOfBands.toInt()) parts.add(e.getBandLevel(b.toShort()).toString())
        Prefs.eqBands = parts.joinToString(",")
    }

    private fun showEffects() {
        val e = eq
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))

        if (e == null) {
            box.addView(label("The equalizer isn't available on this device or for this stream.", 14f, TEXT))
        } else {
            val sw = SwitchCompat(this)
            sw.text = "Equalizer"
            sw.setTextColor(TEXT)
            sw.isChecked = Prefs.eqOn
            sw.setOnCheckedChangeListener { _, on ->
                Prefs.eqOn = on
                e.setEnabled(on)
            }
            box.addView(sw)

            val nb = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            val minL = range[0].toInt()
            val maxL = range[1].toInt()
            val bars = ArrayList<SeekBar>()

            val presets = ArrayList<String>()
            presets.add("Custom")
            for (i in 0 until e.numberOfPresets.toInt()) presets.add(e.getPresetName(i.toShort()))
            val spin = Spinner(this)
            spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets)
            var ready = false
            spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (!ready || position == 0) return
                    e.usePreset((position - 1).toShort())
                    for (b in 0 until nb) bars[b].progress = e.getBandLevel(b.toShort()) - minL
                    saveBands(e)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            box.addView(spin)

            for (b in 0 until nb) {
                val hz = e.getCenterFreq(b.toShort()) / 1000
                val name = if (hz >= 1000) String.format("%.1f kHz", hz / 1000f) else "$hz Hz"
                box.addView(label(name, 12f, MUTED))
                val sb = SeekBar(this)
                sb.max = maxL - minL
                sb.progress = e.getBandLevel(b.toShort()) - minL
                sb.progressTintList = android.content.res.ColorStateList.valueOf(Prefs.accent)
                sb.thumbTintList = android.content.res.ColorStateList.valueOf(Prefs.accent)
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        e.setBandLevel(b.toShort(), (progress + minL).toShort())
                        spin.setSelection(0)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { saveBands(e) }
                })
                bars.add(sb)
                box.addView(sb)
            }
            ready = true
        }

        val l = loud
        box.addView(label("Volume boost", 14f, TEXT, true).also { it.setPadding(0, dp(16), 0, 0) })
        if (l == null) {
            box.addView(label("Not available on this device.", 12f, MUTED))
        } else {
            val boost = SeekBar(this)
            boost.max = 1500
            boost.progress = Prefs.boost.coerceIn(0, 1500)
            boost.progressTintList = android.content.res.ColorStateList.valueOf(Prefs.accent)
            boost.thumbTintList = android.content.res.ColorStateList.valueOf(Prefs.accent)
            val boostLabel = label("+" + boost.progress / 100 + " dB", 12f, MUTED)
            boost.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    boostLabel.text = "+" + progress / 100 + " dB"
                    if (!fromUser) return
                    Prefs.boost = progress
                    l.setTargetGain(progress)
                    l.setEnabled(progress > 0)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(boost)
            box.addView(boostLabel)
        }

        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Audio effects")
            .setView(sv)
            .setPositiveButton("Done", null)
            .show()
    }
}
