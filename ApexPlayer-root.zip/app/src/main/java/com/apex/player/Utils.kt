package com.apex.player

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

/* ---------- models ---------- */

data class Sub(val uri: Uri, val name: String)
data class Entry(val uri: Uri, val title: String, val subs: List<Sub> = emptyList())

/** Hands the playlist from the home screen to the player without squeezing it through an Intent. */
object Queue {
    var items: List<Entry> = emptyList()
    var start: Int = 0
}

/* ---------- file helpers ---------- */

private val SUB_EXT = setOf("srt", "vtt", "ass", "ssa")
private val MEDIA_EXT = setOf(
    "mp4", "m4v", "mkv", "webm", "mov", "avi", "3gp", "ts", "mts", "m2ts", "flv", "wmv", "mpg", "mpeg", "ogv",
    "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "wma", "amr", "mka", "m3u8", "mpd"
)

fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()
fun stripExt(name: String): String = if (name.contains('.')) name.substringBeforeLast('.') else name
fun isSubName(name: String): Boolean = extOf(name) in SUB_EXT
fun isMediaName(name: String): Boolean = extOf(name) in MEDIA_EXT

fun displayName(ctx: Context, uri: Uri): String? {
    if (uri.scheme == "content") {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i)
                }
            }
        } catch (e: Exception) {
            // fall through to the path-based name
        }
    }
    return uri.lastPathSegment?.substringAfterLast('/')
}

fun naturalCompare(a: String, b: String): Int {
    val pa = Regex("\\d+|\\D+").findAll(a.lowercase()).map { it.value }.toList()
    val pb = Regex("\\d+|\\D+").findAll(b.lowercase()).map { it.value }.toList()
    val n = minOf(pa.size, pb.size)
    for (i in 0 until n) {
        val x = pa[i]
        val y = pb[i]
        val nx = x.toLongOrNull()
        val ny = y.toLongOrNull()
        val c = if (nx != null && ny != null) nx.compareTo(ny) else x.compareTo(y)
        if (c != 0) return c
    }
    return pa.size - pb.size
}

/**
 * Turns picked files into playlist entries. Subtitle files are attached to the media file with
 * the same base name (movie.mkv + movie.en.srt). When exactly one video is opened, every
 * subtitle that came with it is attached.
 * [strict] = only accept known media extensions (used for folder scans).
 */
fun buildEntries(files: List<Pair<Uri, String>>, strict: Boolean): List<Entry> {
    val subs = files.filter { isSubName(it.second) }
    val media = files.filter { !isSubName(it.second) && (!strict || isMediaName(it.second)) }
        .sortedWith { a, b -> naturalCompare(a.second, b.second) }
    return media.map { m ->
        val base = stripExt(m.second).lowercase()
        var mine = subs.filter {
            val sb = stripExt(it.second).lowercase()
            sb == base || sb.startsWith("$base.")
        }
        if (mine.isEmpty() && media.size == 1) mine = subs
        Entry(m.first, stripExt(m.second), mine.map { Sub(it.first, it.second) })
    }
}

/* ---------- UI helpers (the app is built in code, so there are no layout files to keep in sync) ---------- */

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

val TEXT = Color.parseColor("#F2EDFC")
val MUTED = Color.parseColor("#A99DC8")
val LINE = Color.parseColor("#33C4AAFF")
val SURFACE = Color.parseColor("#1F1634")

fun appBackground(): GradientDrawable {
    val colors = if (Prefs.amoled) intArrayOf(Color.BLACK, Color.BLACK)
    else intArrayOf(Color.parseColor("#26124A"), Color.parseColor("#0D0716"))
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
}

fun Context.rounded(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun inkOn(color: Int): Int {
    val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
    return if (lum > 0.6) Color.parseColor("#241400") else Color.WHITE
}

fun Context.label(text: String, sizeSp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextColor(color)
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

/** A pill-shaped button. [filled] uses the accent colour; otherwise it is an outline. */
fun Context.pill(text: String, filled: Boolean, onClick: () -> Unit): TextView {
    val acc = Prefs.accent
    val t = label(text, 14f, if (filled) inkOn(acc) else TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(16), dp(10), dp(16), dp(10))
    t.background = if (filled) rounded(acc, 22) else rounded(Color.parseColor("#22FFFFFF"), 22, LINE, 1)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

fun Context.sectionTitle(text: String): TextView {
    val t = label(text.uppercase(), 11f, Prefs.accent, true)
    t.letterSpacing = 0.16f
    t.setPadding(0, dp(22), 0, dp(6))
    return t
}

fun Context.divider(): View {
    val v = View(this)
    v.setBackgroundColor(LINE)
    v.layoutParams = LinearLayout.LayoutParams(MATCH, 1)
    return v
}

fun Context.switchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, dp(10), 0, dp(10))
    val texts = LinearLayout(this)
    texts.orientation = LinearLayout.VERTICAL
    texts.addView(label(title, 15f))
    if (desc != null) texts.addView(label(desc, 12f, MUTED))
    row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
    val sw = SwitchCompat(this)
    sw.isChecked = checked
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    sw.thumbTintList = ColorStateList(states, intArrayOf(Prefs.accent, Color.parseColor("#8E84A8")))
    val trackOn = (Prefs.accent and 0x00FFFFFF) or 0x66000000
    sw.trackTintList = ColorStateList(states, intArrayOf(trackOn, Color.parseColor("#33FFFFFF")))
    sw.setOnCheckedChangeListener { _, on -> onChange(on) }
    row.addView(sw)
    row.setOnClickListener { sw.toggle() }
    return row
}

fun Context.seekRow(title: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit): View {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(0, dp(10), 0, dp(10))
    val head = LinearLayout(this)
    head.orientation = LinearLayout.HORIZONTAL
    head.addView(label(title, 15f), LinearLayout.LayoutParams(0, WRAP, 1f))
    val val_ = label("$value$unit", 13f, Prefs.accent, true)
    head.addView(val_)
    box.addView(head)
    val sb = SeekBar(this)
    sb.max = max - min
    sb.progress = value - min
    sb.progressTintList = ColorStateList.valueOf(Prefs.accent)
    sb.thumbTintList = ColorStateList.valueOf(Prefs.accent)
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            val v = p + min
            val_.text = "$v$unit"
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    box.addView(sb)
    return box
}

fun Context.segRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(0, dp(10), 0, dp(10))
    box.addView(label(title, 15f))
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.setPadding(0, dp(8), 0, 0)
    val chips = ArrayList<TextView>()
    fun paint(sel: Int) {
        chips.forEachIndexed { i, c ->
            val on = i == sel
            c.setTextColor(if (on) inkOn(Prefs.accent) else TEXT)
            c.background = if (on) rounded(Prefs.accent, 18) else rounded(Color.parseColor("#22FFFFFF"), 18, LINE, 1)
        }
    }
    options.forEachIndexed { i, o ->
        val c = label(o, 13f, TEXT, true)
        c.gravity = Gravity.CENTER
        c.setPadding(dp(14), dp(8), dp(14), dp(8))
        c.setOnClickListener { paint(i); onSelect(i) }
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.rightMargin = dp(6)
        row.addView(c, lp)
        chips.add(c)
    }
    paint(selected)
    box.addView(row)
    return box
}

fun Context.swatchRow(title: String, colors: List<Int>, selected: Int, onSelect: (Int) -> Unit): View {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(0, dp(10), 0, dp(10))
    box.addView(label(title, 15f))
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.setPadding(0, dp(10), 0, 0)
    val dots = ArrayList<View>()
    fun paint(sel: Int) {
        dots.forEachIndexed { i, d ->
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(colors[i])
            if (colors[i] == sel) g.setStroke(dp(3), Color.WHITE)
            d.background = g
        }
    }
    colors.forEach { c ->
        val d = View(this)
        d.setOnClickListener { paint(c); onSelect(c) }
        val lp = LinearLayout.LayoutParams(dp(36), dp(36))
        lp.rightMargin = dp(10)
        row.addView(d, lp)
        dots.add(d)
    }
    paint(selected)
    box.addView(row)
    return box
}
