# Apex Player (Android)

A native Android video and music player built on Media3/ExoPlayer, with the Apex icon.

## Get the APK with GitHub (about 5 minutes, no computer tools needed beyond a browser)

1. Create a free GitHub account and a **new repository** (any name, Public or Private).
2. Upload every file and folder from this project into the repository.
   - On a computer: open the repo, choose **Add file → Upload files**, and drag in the *contents* of this folder. Make sure the hidden `.github` folder goes up too.
   - If `.github` won't upload: choose **Add file → Create new file**, type `.github/workflows/build-apk.yml` as the name, and paste in the contents of that file.
3. Open the repository's **Actions** tab. The build starts by itself after you upload (or press **Run workflow**). It takes 4 to 8 minutes.
4. When it turns green, open the repository's **Releases** (right-hand side of the repo page). Download **ApexPlayer.apk** from the newest release.
5. Open the APK on your phone. Android will ask you to allow installs from your browser or file manager. Allow it, then install.

The APK is a signed **release** build. The signing key (`app/apex-release.jks`, password `apexplayer`) is included so every build can update the previous install. If your repository is Public, anyone can see that key, so make the repository **Private**, or generate your own key before publishing to the Play Store.

If the build fails, open the failed run, copy the red error text and send it to me. I'll fix it.

## What's inside

- Plays video and audio files, whole folders, and network streams (HTTP, HLS, DASH)
- Playlist with next/previous, shuffle and repeat
- Subtitles: SRT, VTT and ASS. Picked up automatically when they share a name with the video, or add one from the top bar
- Multiple audio tracks and multiple subtitle tracks: switch them from the **Audio** and **Subtitles** buttons in the top bar (shows language, codec and channels, e.g. "English · AC3 5.1"). Speed control is in the gear menu
- Gestures: swipe to seek, left edge brightness, right edge volume, double-tap to skip, touch and hold for 2×, pinch to zoom
- A–B loop, aspect modes (fit, stretch, crop, fit width, fit height), screen rotation lock, control lock
- Equalizer with presets and a volume boost
- Sleep timer, picture-in-picture, resume where you left off, continue-watching list
- Settings: accent colour, AMOLED black, control timeout, default picture size, subtitle size and colour, skip step, gesture switches

## Limits to know about

- Audio: an FFmpeg software decoder is built in, so AC3, E-AC3, DTS, DTS-HD, TrueHD, FLAC, ALAC, Opus, Vorbis, MP3 and AAC all play on any phone.
- Video uses your phone's hardware decoder (like MX Player's HW mode). Most phones handle H.264, HEVC and VP9. Very old formats (some WMV/RealVideo/MPEG-4 ASP in AVI) or HEVC on a weak budget phone may not show picture.
- Background audio stops when you leave the app unless you turn off "Pause when you leave the app" in Settings. There is no lock-screen player yet.
